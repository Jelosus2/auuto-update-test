export declare const characters: {
    [key: string]: any;
};
