export declare const hashes: {
    [key: string]: any;
};
