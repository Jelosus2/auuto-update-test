export declare const namecards: {
    [key: string]: any;
};
