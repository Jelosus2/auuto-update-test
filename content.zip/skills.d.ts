export declare const skills: {
    [key: string]: any;
};
