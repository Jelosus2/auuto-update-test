"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.skills = void 0;
exports.skills = {
    "10011": {
        nameTextMapHash: "2749847941",
        icon: "Skill_A_01",
    },
    "10111": {
        nameTextMapHash: "1707104125",
        icon: "Skill_A_01",
    },
    "10012": {
        nameTextMapHash: "3276358165",
        icon: "Skill_S_Kate_01",
    },
    "10013": {
        nameTextMapHash: "2687935733",
        icon: "Skill_S_Ayaka_02",
    },
    "10014": {
        nameTextMapHash: "3173933501",
        icon: "Skill_E_Kate",
    },
    "10015": {
        nameTextMapHash: "3857388709",
        icon: "Skill_E_Ayaka",
    },
    "10016": {
        nameTextMapHash: "4018326997",
        icon: "Skill_E_Qin",
    },
    "10017": {
        nameTextMapHash: "4246808797",
        icon: "Skill_E_Ambor",
    },
    "10018": {
        nameTextMapHash: "682887613",
        icon: "Skill_S_Ayaka_01",
    },
    "10019": {
        nameTextMapHash: "81399925",
        icon: "Skill_E_Ayaka",
    },
    "10020": {
        nameTextMapHash: "328228597",
        icon: "Skill_S_Ayaka_01",
    },
    "10021": {
        nameTextMapHash: "1098937701",
        icon: "Skill_E_Ayaka",
    },
    "10022": {
        nameTextMapHash: "2000442733",
        icon: "Skill_E_Ayaka",
    },
    "10023": {
        nameTextMapHash: "1555859989",
        icon: "Skill_S_Ayaka_01",
    },
    "10024": {
        nameTextMapHash: "813430205",
        icon: "Skill_A_01",
    },
    "10031": {
        nameTextMapHash: "3128535397",
        icon: "Skill_A_01",
    },
    "10032": {
        nameTextMapHash: "3667697773",
        icon: "Skill_S_Ambor_01",
    },
    "10033": {
        nameTextMapHash: "1433276421",
        icon: "Skill_S_Qin_02",
    },
    "10034": {
        nameTextMapHash: "1586562613",
        icon: "Skill_E_Qin_01",
    },
    "10035": {
        nameTextMapHash: "583200773",
        icon: "Btn_Recon_Bait",
    },
    "10036": {
        nameTextMapHash: "3749906165",
        icon: "Skill_E_Kate",
    },
    "10037": {
        nameTextMapHash: "4139817517",
        icon: "Btn_Recon_Bait",
    },
    "10038": {
        nameTextMapHash: "4076045861",
        icon: "Btn_Recon_Bait_Beans",
    },
    "10041": {
        nameTextMapHash: "1422444957",
        icon: "Skill_A_02",
    },
    "10042": {
        nameTextMapHash: "1423809501",
        icon: "Skill_A_02",
    },
    "10043": {
        nameTextMapHash: "3408079909",
        icon: "Skill_A_02",
    },
    "10044": {
        nameTextMapHash: "2920773085",
        icon: "Skill_E_Kate",
    },
    "10051": {
        nameTextMapHash: "355609901",
        icon: "Skill_A_01",
    },
    "10052": {
        nameTextMapHash: "1337443333",
        icon: "Skill_A_01",
    },
    "10053": {
        nameTextMapHash: "4264864229",
        icon: "Skill_S_Ayaka_02",
    },
    "10054": {
        nameTextMapHash: "3282423005",
        icon: "Skill_A_01",
    },
    "10055": {
        nameTextMapHash: "2474303229",
        icon: "Skill_A_01",
    },
    "10056": {
        nameTextMapHash: "4043949413",
        icon: "Skill_A_01",
    },
    "10057": {
        nameTextMapHash: "2359717149",
        icon: "Skill_A_01",
    },
    "10058": {
        nameTextMapHash: "4157484933",
        icon: "Skill_A_01",
    },
    "10059": {
        nameTextMapHash: "2060938949",
        icon: "Skill_A_01",
    },
    "10060": {
        nameTextMapHash: "2499144501",
        icon: "Skill_A_Catalyst_MD",
    },
    "10061": {
        nameTextMapHash: "3342928733",
        icon: "Skill_S_Lisa_01",
    },
    "10062": {
        nameTextMapHash: "3387608453",
        icon: "Skill_E_Lisa_01",
    },
    "10063": {
        nameTextMapHash: "2586290485",
        icon: "Skill_E_Ayaka",
    },
    "10064": {
        nameTextMapHash: "525869677",
        icon: "Skill_S_Ayaka_01",
    },
    "10065": {
        nameTextMapHash: "1490087445",
        icon: "Skill_S_Ambor_01",
    },
    "10066": {
        nameTextMapHash: "3115053829",
        icon: "Skill_E_Kate",
    },
    "10067": {
        nameTextMapHash: "2639384229",
        icon: "Skill_S_PlayerWind_01",
    },
    "10068": {
        nameTextMapHash: "565740677",
        icon: "Skill_E_PlayerWind_01",
    },
    "10069": {
        nameTextMapHash: "1982944773",
        icon: "Skill_A_01",
    },
    "10070": {
        nameTextMapHash: "1555695317",
        icon: "Skill_A_Catalyst_MD",
    },
    "10071": {
        nameTextMapHash: "645814357",
        icon: "Skill_S_Barbara_01",
    },
    "10072": {
        nameTextMapHash: "3238780589",
        icon: "Skill_E_Barbara_01",
    },
    "10073": {
        nameTextMapHash: "3795823997",
        icon: "Skill_A_01",
    },
    "10074": {
        nameTextMapHash: "1067425573",
        icon: "Skill_S_Kaeya_01",
    },
    "10075": {
        nameTextMapHash: "2486277181",
        icon: "Skill_E_Kaeya_01",
    },
    "10076": {
        nameTextMapHash: "2500956509",
        icon: "Skill_E_Kate",
    },
    "10077": {
        nameTextMapHash: "65936957",
        icon: "Skill_S_PlayerRock_01",
    },
    "10078": {
        nameTextMapHash: "1608625765",
        icon: "Skill_E_PlayerRock_01",
    },
    "10079": {
        nameTextMapHash: "2082103149",
        icon: "Skill_E_Kate",
    },
    "10080": {
        nameTextMapHash: "3119510045",
        icon: "Skill_E_Kate",
    },
    "10081": {
        nameTextMapHash: "1904017997",
        icon: "Skill_E_Kate",
    },
    "10082": {
        nameTextMapHash: "421173349",
        icon: "Skill_E_Kate",
    },
    "10083": {
        nameTextMapHash: "2350480557",
        icon: "Skill_E_Kate",
    },
    "10117": {
        nameTextMapHash: "2178570213",
        icon: "Skill_E_PlayerGrass_01",
    },
    "10118": {
        nameTextMapHash: "2504837493",
        icon: "Skill_S_PlayerGrass_01",
    },
    "10160": {
        nameTextMapHash: "2878874285",
        icon: "Skill_A_04",
    },
    "10161": {
        nameTextMapHash: "2979035429",
        icon: "Skill_S_Diluc_01_01",
    },
    "10162": {
        nameTextMapHash: "3312056637",
        icon: "Skill_S_Diluc_01_02",
    },
    "10163": {
        nameTextMapHash: "4175685277",
        icon: "Skill_S_Diluc_01_03",
    },
    "10165": {
        nameTextMapHash: "2772119557",
        icon: "Skill_E_Diluc_01",
    },
    "10166": {
        nameTextMapHash: "533094517",
        icon: "Skill_E_Kate",
    },
    "10201": {
        nameTextMapHash: "3392494725",
        icon: "Skill_A_04",
    },
    "10202": {
        nameTextMapHash: "2720517437",
        icon: "Skill_S_Razor_01",
    },
    "10203": {
        nameTextMapHash: "1752405213",
        icon: "Skill_E_Razor_01",
    },
    "10204": {
        nameTextMapHash: "4072488965",
        icon: "Skill_S_Ayaka_02",
    },
    "10211": {
        nameTextMapHash: "2104569853",
        icon: "Skill_A_02",
    },
    "10221": {
        nameTextMapHash: "4043029317",
        icon: "Skill_A_02",
    },
    "10222": {
        nameTextMapHash: "2037043829",
        icon: "Skill_A_02",
    },
    "10223": {
        nameTextMapHash: "3736134253",
        icon: "Skill_A_02",
    },
    "10224": {
        nameTextMapHash: "2470093149",
        icon: "Skill_S_Venti_01",
    },
    "10225": {
        nameTextMapHash: "1181756941",
        icon: "Skill_E_Venti_01",
    },
    "10231": {
        nameTextMapHash: "2921789333",
        icon: "Skill_A_03",
    },
    "10232": {
        nameTextMapHash: "1925269741",
        icon: "Skill_S_Xiangling_01",
    },
    "10235": {
        nameTextMapHash: "3051726149",
        icon: "Skill_E_Xiangling_01",
    },
    "10241": {
        nameTextMapHash: "3770302877",
        icon: "Skill_A_04",
    },
    "10242": {
        nameTextMapHash: "3028116765",
        icon: "Skill_S_Beidou_01",
    },
    "10245": {
        nameTextMapHash: "2874294485",
        icon: "Skill_E_Beidou_01",
    },
    "20000": {
        nameTextMapHash: "3786268365",
        icon: "Main_AimActive",
    },
    "10251": {
        nameTextMapHash: "2739745653",
        icon: "Skill_A_02",
    },
    "10252": {
        nameTextMapHash: "1214405501",
        icon: "Skill_A_02",
    },
    "10253": {
        nameTextMapHash: "2244025589",
        icon: "Skill_A_02",
    },
    "10254": {
        nameTextMapHash: "2086557645",
        icon: "Skill_S_Ayaka_01",
    },
    "10255": {
        nameTextMapHash: "2223041389",
        icon: "Skill_E_Ayaka",
    },
    "10261": {
        nameTextMapHash: "232048445",
        icon: "Skill_A_03",
    },
    "10262": {
        nameTextMapHash: "45357229",
        icon: "Skill_S_Xiao_01",
    },
    "10263": {
        nameTextMapHash: "4121034669",
        icon: "Skill_S_Xiao_01",
    },
    "10264": {
        nameTextMapHash: "1846272605",
        icon: "Skill_A_03",
    },
    "10265": {
        nameTextMapHash: "2396025797",
        icon: "Skill_E_Xiao_01",
    },
    "10271": {
        nameTextMapHash: "2745030989",
        icon: "Skill_A_Catalyst_MD",
    },
    "10272": {
        nameTextMapHash: "2863733197",
        icon: "Skill_S_Ningguang_01",
    },
    "10273": {
        nameTextMapHash: "3585226285",
        icon: "Skill_S_Ningguang_02",
    },
    "10274": {
        nameTextMapHash: "3719617877",
        icon: "Skill_E_Ningguang_01",
    },
    "10275": {
        nameTextMapHash: "1679764893",
        icon: "Skill_E_Ayaka",
    },
    "10281": {
        nameTextMapHash: "1174655621",
        icon: "Skill_A_01",
    },
    "10282": {
        nameTextMapHash: "2731359549",
        icon: "Skill_A_01",
    },
    "10283": {
        nameTextMapHash: "172556125",
        icon: "Skill_S_Ayaka_01",
    },
    "10291": {
        nameTextMapHash: "161160581",
        icon: "Skill_A_Catalyst_MD",
    },
    "10292": {
        nameTextMapHash: "3723743117",
        icon: "Skill_S_Klee_01",
    },
    "10295": {
        nameTextMapHash: "1371192733",
        icon: "Skill_E_Klee_01",
    },
    "10300": {
        nameTextMapHash: "2269097229",
        icon: "Skill_A_01",
    },
    "10301": {
        nameTextMapHash: "2119081949",
        icon: "Skill_A_03",
    },
    "10302": {
        nameTextMapHash: "3426814373",
        icon: "Skill_S_Zhongli_01",
    },
    "10303": {
        nameTextMapHash: "3055197325",
        icon: "Skill_E_Zhongli_01",
    },
    "10311": {
        nameTextMapHash: "3733168437",
        icon: "Skill_A_02",
    },
    "10312": {
        nameTextMapHash: "2390005205",
        icon: "Skill_S_Fischl_01",
    },
    "10313": {
        nameTextMapHash: "1386345573",
        icon: "Skill_E_Fischl_01",
    },
    "10314": {
        nameTextMapHash: "3301569901",
        icon: "Skill_A_02",
    },
    "10315": {
        nameTextMapHash: "1197592453",
        icon: "Skill_A_02",
    },
    "10316": {
        nameTextMapHash: "3957763109",
        icon: "Skill_S_Fischl_02",
    },
    "10321": {
        nameTextMapHash: "422353221",
        icon: "Skill_A_01",
    },
    "10322": {
        nameTextMapHash: "1809314813",
        icon: "Skill_S_Bennett_01",
    },
    "10323": {
        nameTextMapHash: "3528607669",
        icon: "Skill_E_Bennett_01",
    },
    "10331": {
        nameTextMapHash: "2900039733",
        icon: "Skill_A_02",
    },
    "10332": {
        nameTextMapHash: "863456805",
        icon: "Skill_S_Tartaglia_01",
    },
    "10333": {
        nameTextMapHash: "2804759909",
        icon: "Skill_E_Tartaglia_01",
    },
    "10334": {
        nameTextMapHash: "359566701",
        icon: "Skill_A_02",
    },
    "10335": {
        nameTextMapHash: "2864617109",
        icon: "Skill_A_02",
    },
    "10336": {
        nameTextMapHash: "3093740965",
        icon: "Skill_S_Tartaglia_02",
    },
    "10337": {
        nameTextMapHash: "2810970837",
        icon: "Skill_A_01",
    },
    "10341": {
        nameTextMapHash: "1521716213",
        icon: "Skill_A_04",
    },
    "10342": {
        nameTextMapHash: "737506901",
        icon: "Skill_S_Noel_01",
    },
    "10343": {
        nameTextMapHash: "1615963973",
        icon: "Skill_E_Noel_01",
    },
    "10344": {
        nameTextMapHash: "2455313621",
        icon: "Skill_E_Kate",
    },
    "10351": {
        nameTextMapHash: "1361102277",
        icon: "Skill_A_01",
    },
    "10352": {
        nameTextMapHash: "2328467573",
        icon: "Skill_S_Qiqi_01",
    },
    "10353": {
        nameTextMapHash: "2926659693",
        icon: "Skill_E_Qiqi_01",
    },
    "10355": {
        nameTextMapHash: "443303565",
        icon: "Skill_E_Kate",
    },
    "10371": {
        nameTextMapHash: "798389461",
        icon: "Skill_A_02",
    },
    "10372": {
        nameTextMapHash: "1812426093",
        icon: "Skill_S_Ganyu_01",
    },
    "10373": {
        nameTextMapHash: "683098317",
        icon: "Skill_E_Ganyu_01",
    },
    "10374": {
        nameTextMapHash: "1660440365",
        icon: "Skill_A_02",
    },
    "11301": {
        nameTextMapHash: "3802462781",
        icon: "Skill_A_02",
    },
    "11302": {
        nameTextMapHash: "2467360621",
        icon: "Skill_S_Ambor_01",
    },
    "11305": {
        nameTextMapHash: "3542308085",
        icon: "Skill_E_Beidou_01",
    },
    "10256": {
        nameTextMapHash: "2869756949",
        icon: "Skill_S_Ayaka_01",
    },
    "10257": {
        nameTextMapHash: "638400197",
        icon: "Skill_S_Ayaka_01",
    },
    "10258": {
        nameTextMapHash: "1765614717",
        icon: "Skill_S_Ayaka_01",
    },
    "10259": {
        nameTextMapHash: "1588300309",
        icon: "Skill_E_Ayaka",
    },
    "10362": {
        nameTextMapHash: "911388717",
        icon: "Skill_E_Ayaka",
    },
    "10363": {
        nameTextMapHash: "3877347189",
        icon: "Skill_E_Ayaka",
    },
    "10364": {
        nameTextMapHash: "389819541",
        icon: "Skill_S_Ayaka_01",
    },
    "10365": {
        nameTextMapHash: "3238405613",
        icon: "Skill_E_Ayaka",
    },
    "11371": {
        nameTextMapHash: "3471617741",
        icon: "Skill_A_02",
    },
    "11372": {
        nameTextMapHash: "887901653",
        icon: "Skill_S_Razor_01",
    },
    "11373": {
        nameTextMapHash: "2373915949",
        icon: "Skill_E_Razor_01",
    },
    "11374": {
        nameTextMapHash: "3115055061",
        icon: "Skill_A_02",
    },
    "11375": {
        nameTextMapHash: "1184917301",
        icon: "Skill_A_02",
    },
    "10381": {
        nameTextMapHash: "3909984477",
        icon: "Skill_A_01",
    },
    "10382": {
        nameTextMapHash: "4213665965",
        icon: "Skill_S_Xingqiu_01",
    },
    "10385": {
        nameTextMapHash: "3014291477",
        icon: "Skill_E_Xingqiu_01",
    },
    "10386": {
        nameTextMapHash: "1763139317",
        icon: "Skill_A_01",
    },
    "10387": {
        nameTextMapHash: "4277075117",
        icon: "Skill_S_Albedo_01",
    },
    "10388": {
        nameTextMapHash: "1170150789",
        icon: "Skill_E_Albedo_01",
    },
    "10391": {
        nameTextMapHash: "3860542709",
        icon: "Skill_A_02",
    },
    "10392": {
        nameTextMapHash: "3942666181",
        icon: "Skill_S_Diona_01",
    },
    "10393": {
        nameTextMapHash: "1792093821",
        icon: "Skill_A_02",
    },
    "10394": {
        nameTextMapHash: "723718077",
        icon: "Skill_A_02",
    },
    "10395": {
        nameTextMapHash: "948563965",
        icon: "Skill_E_Diona_01",
    },
    "10401": {
        nameTextMapHash: "1917853333",
        icon: "Skill_A_04",
    },
    "10402": {
        nameTextMapHash: "1241562797",
        icon: "Skill_S_Chongyun_01",
    },
    "10403": {
        nameTextMapHash: "514253413",
        icon: "Skill_E_Chongyun_01",
    },
    "10411": {
        nameTextMapHash: "2512572181",
        icon: "Skill_A_Catalyst_MD",
    },
    "10412": {
        nameTextMapHash: "1125648053",
        icon: "Skill_S_Mona_01",
    },
    "10413": {
        nameTextMapHash: "1057341493",
        icon: "Skill_S_Mona_02",
    },
    "10415": {
        nameTextMapHash: "3616116589",
        icon: "Skill_E_Mona_01",
    },
    "10421": {
        nameTextMapHash: "1732155229",
        icon: "Skill_A_01",
    },
    "10422": {
        nameTextMapHash: "2146753981",
        icon: "Skill_S_Keqing_01",
    },
    "10423": {
        nameTextMapHash: "3841583165",
        icon: "Skill_S_Keqing_02",
    },
    "10425": {
        nameTextMapHash: "535180037",
        icon: "Skill_E_Keqing_01",
    },
    "10431": {
        nameTextMapHash: "3941337549",
        icon: "Skill_A_Catalyst_MD",
    },
    "10432": {
        nameTextMapHash: "159360653",
        icon: "Skill_S_Sucrose_01",
    },
    "10433": {
        nameTextMapHash: "4220161669",
        icon: "Skill_S_Sucrose_02",
    },
    "10434": {
        nameTextMapHash: "1745727853",
        icon: "Skill_S_Sucrose_02",
    },
    "10435": {
        nameTextMapHash: "234765309",
        icon: "Skill_E_Sucrose_01",
    },
    "10441": {
        nameTextMapHash: "327566445",
        icon: "Skill_A_04",
    },
    "10442": {
        nameTextMapHash: "980327173",
        icon: "Skill_S_Xinyan_01",
    },
    "10443": {
        nameTextMapHash: "405900781",
        icon: "Skill_E_Xinyan_01",
    },
    "10451": {
        nameTextMapHash: "37074469",
        icon: "Skill_A_03",
    },
    "10452": {
        nameTextMapHash: "2398605029",
        icon: "Skill_S_Rosaria_01",
    },
    "10453": {
        nameTextMapHash: "3067800421",
        icon: "Skill_E_Rosaria_01",
    },
    "10461": {
        nameTextMapHash: "2345944629",
        icon: "Skill_A_03",
    },
    "10462": {
        nameTextMapHash: "214248165",
        icon: "Skill_S_Hutao_01",
    },
    "10463": {
        nameTextMapHash: "1115787101",
        icon: "Skill_E_Hutao_01",
    },
    "10464": {
        nameTextMapHash: "268015821",
        icon: "Skill_A_03",
    },
    "10471": {
        nameTextMapHash: "137786925",
        icon: "Skill_A_01",
    },
    "10472": {
        nameTextMapHash: "3645237197",
        icon: "Skill_S_Kazuha_01",
    },
    "10473": {
        nameTextMapHash: "1245826445",
        icon: "Skill_S_Kazuha_01",
    },
    "10474": {
        nameTextMapHash: "738388789",
        icon: "Skill_S_Kazuha_02",
    },
    "10475": {
        nameTextMapHash: "2015878197",
        icon: "Skill_E_Kazuha_01",
    },
    "10481": {
        nameTextMapHash: "2553270533",
        icon: "Skill_A_Catalyst_MD",
    },
    "10482": {
        nameTextMapHash: "4230930285",
        icon: "Skill_S_Feiyan_01",
    },
    "10485": {
        nameTextMapHash: "3041237813",
        icon: "Skill_E_Feiyan_01",
    },
    "10491": {
        nameTextMapHash: "1887244733",
        icon: "Skill_A_02",
    },
    "10492": {
        nameTextMapHash: "3119836125",
        icon: "Skill_S_Yoimiya_01",
    },
    "10493": {
        nameTextMapHash: "3811849605",
        icon: "Skill_A_02",
    },
    "10495": {
        nameTextMapHash: "4251575685",
        icon: "Skill_E_Yoimiya_01",
    },
    "10501": {
        nameTextMapHash: "3651752365",
        icon: "Skill_A_03",
    },
    "10502": {
        nameTextMapHash: "3732507581",
        icon: "Skill_S_Tohma_01",
    },
    "10505": {
        nameTextMapHash: "3548079181",
        icon: "Skill_E_Tohma_01",
    },
    "10511": {
        nameTextMapHash: "242311157",
        icon: "Skill_A_04",
    },
    "10512": {
        nameTextMapHash: "741315613",
        icon: "Skill_S_Eula_01",
    },
    "10515": {
        nameTextMapHash: "3521320029",
        icon: "Skill_E_Eula_01",
    },
    "10521": {
        nameTextMapHash: "1302153717",
        icon: "Skill_A_03",
    },
    "10522": {
        nameTextMapHash: "1312969485",
        icon: "Skill_S_Shougun_01",
    },
    "10525": {
        nameTextMapHash: "725251661",
        icon: "Skill_E_Shougun_01",
    },
    "10531": {
        nameTextMapHash: "1631640581",
        icon: "Skill_A_04",
    },
    "10532": {
        nameTextMapHash: "866970125",
        icon: "Skill_S_Sayu_01",
    },
    "10533": {
        nameTextMapHash: "2724434029",
        icon: "Skill_S_Sayu_02",
    },
    "10535": {
        nameTextMapHash: "3632447629",
        icon: "Skill_E_Sayu_01",
    },
    "10541": {
        nameTextMapHash: "3150512989",
        icon: "Skill_A_Catalyst_MD",
    },
    "10542": {
        nameTextMapHash: "369441117",
        icon: "Skill_S_Kokomi_01",
    },
    "10545": {
        nameTextMapHash: "2835602565",
        icon: "Skill_E_Kokomi_01",
    },
    "10551": {
        nameTextMapHash: "527760517",
        icon: "Skill_A_02",
    },
    "10552": {
        nameTextMapHash: "2527853093",
        icon: "Skill_S_Gorou_01",
    },
    "10553": {
        nameTextMapHash: "3165585093",
        icon: "Skill_A_02",
    },
    "10554": {
        nameTextMapHash: "2798026229",
        icon: "Skill_A_02",
    },
    "10555": {
        nameTextMapHash: "406282597",
        icon: "Skill_E_Gorou_01",
    },
    "10561": {
        nameTextMapHash: "1547762373",
        icon: "Skill_A_02",
    },
    "10562": {
        nameTextMapHash: "2752568269",
        icon: "Skill_S_Sara_01",
    },
    "10563": {
        nameTextMapHash: "4243606493",
        icon: "Skill_A_02",
    },
    "10564": {
        nameTextMapHash: "1162004437",
        icon: "Skill_A_02",
    },
    "10565": {
        nameTextMapHash: "2275338309",
        icon: "Skill_E_Sara_01",
    },
    "10571": {
        nameTextMapHash: "1791467005",
        icon: "Skill_A_04",
    },
    "10572": {
        nameTextMapHash: "1142785501",
        icon: "Skill_S_Itto_01",
    },
    "10575": {
        nameTextMapHash: "3385637213",
        icon: "Skill_E_Itto_01",
    },
    "10581": {
        nameTextMapHash: "3966360853",
        icon: "Skill_A_Catalyst_MD",
    },
    "10582": {
        nameTextMapHash: "823035501",
        icon: "Skill_S_Yae_01",
    },
    "10585": {
        nameTextMapHash: "3675029365",
        icon: "Skill_E_Yae_01",
    },
    "10591": {
        nameTextMapHash: "2195671413",
        icon: "Skill_A_Catalyst_MD",
    },
    "10592": {
        nameTextMapHash: "3012298293",
        icon: "Skill_S_Heizo_01",
    },
    "10595": {
        nameTextMapHash: "3584687669",
        icon: "Skill_E_Heizo_01",
    },
    "10602": {
        nameTextMapHash: "123614933",
        icon: "Skill_S_PlayerElectric_01",
    },
    "10605": {
        nameTextMapHash: "1169939717",
        icon: "Skill_E_PlayerElectric_01",
    },
    "10606": {
        nameTextMapHash: "1713742645",
        icon: "Skill_A_02",
    },
    "10607": {
        nameTextMapHash: "890827533",
        icon: "Skill_S_Yelan_01",
    },
    "10608": {
        nameTextMapHash: "682555157",
        icon: "Skill_A_02",
    },
    "10609": {
        nameTextMapHash: "2743164485",
        icon: "Skill_S_Yelan_02",
    },
    "10610": {
        nameTextMapHash: "4098371861",
        icon: "Skill_E_Yelan_01",
    },
    "10621": {
        nameTextMapHash: "2994648485",
        icon: "Skill_A_02",
    },
    "10622": {
        nameTextMapHash: "1871687965",
        icon: "Skill_S_Aloy_01",
    },
    "10623": {
        nameTextMapHash: "2840824533",
        icon: "Skill_A_02",
    },
    "10624": {
        nameTextMapHash: "3778025661",
        icon: "Skill_A_02",
    },
    "10631": {
        nameTextMapHash: "2933047013",
        icon: "Skill_A_03",
    },
    "10632": {
        nameTextMapHash: "3028595085",
        icon: "Skill_S_Shenhe_01",
    },
    "10635": {
        nameTextMapHash: "207401861",
        icon: "Skill_E_Shenhe_01",
    },
    "10625": {
        nameTextMapHash: "902219717",
        icon: "Skill_E_Aloy_01",
    },
    "10641": {
        nameTextMapHash: "4286587805",
        icon: "Skill_A_03",
    },
    "10642": {
        nameTextMapHash: "2178272253",
        icon: "Skill_S_Yunjin_01",
    },
    "10643": {
        nameTextMapHash: "3248431565",
        icon: "Skill_E_Yunjin_01",
    },
    "10651": {
        nameTextMapHash: "2013854373",
        icon: "Skill_A_01",
    },
    "10652": {
        nameTextMapHash: "1345666909",
        icon: "Skill_S_Shinobu_01",
    },
    "10655": {
        nameTextMapHash: "1690703909",
        icon: "Skill_E_Shinobu_01",
    },
    "10656": {
        nameTextMapHash: "3057382629",
        icon: "Skill_A_03",
    },
    "10657": {
        nameTextMapHash: "3552450509",
        icon: "Skill_A_03",
    },
    "10661": {
        nameTextMapHash: "3116393605",
        icon: "Skill_A_01",
    },
    "10662": {
        nameTextMapHash: "856237685",
        icon: "Skill_S_Ayato_01",
    },
    "10663": {
        nameTextMapHash: "433582069",
        icon: "Skill_A_01",
    },
    "10665": {
        nameTextMapHash: "2907386981",
        icon: "Skill_E_Ayato_01",
    },
    "10671": {
        nameTextMapHash: "3768859965",
        icon: "Skill_A_02",
    },
    "10672": {
        nameTextMapHash: "2943851901",
        icon: "Skill_S_Collei_01",
    },
    "10675": {
        nameTextMapHash: "1430301637",
        icon: "Skill_E_Collei_01",
    },
    "10674": {
        nameTextMapHash: "3984738037",
        icon: "Skill_A_02",
    },
    "10681": {
        nameTextMapHash: "3134128957",
        icon: "Skill_A_04",
    },
    "10682": {
        nameTextMapHash: "2851422357",
        icon: "Skill_S_Dori_01",
    },
    "10685": {
        nameTextMapHash: "4155943733",
        icon: "Skill_E_Dori_01",
    },
    "10691": {
        nameTextMapHash: "3409522557",
        icon: "Skill_A_02",
    },
    "10692": {
        nameTextMapHash: "3726986301",
        icon: "Skill_S_Tighnari_01",
    },
    "10693": {
        nameTextMapHash: "1376683245",
        icon: "Skill_A_02",
    },
    "10695": {
        nameTextMapHash: "3822928381",
        icon: "Skill_E_Tighnari_01",
    },
    "10701": {
        nameTextMapHash: "1390577909",
        icon: "Skill_A_01",
    },
    "10702": {
        nameTextMapHash: "2640547533",
        icon: "Skill_S_Nilou_01",
    },
    "10703": {
        nameTextMapHash: "509298485",
        icon: "Skill_S_Nilou_01",
    },
    "10704": {
        nameTextMapHash: "3085221333",
        icon: "Skill_S_Nilou_01",
    },
    "10706": {
        nameTextMapHash: "2642188701",
        icon: "Skill_S_Nilou_04",
    },
    "10707": {
        nameTextMapHash: "2011484461",
        icon: "Skill_S_Nilou_02",
    },
    "10705": {
        nameTextMapHash: "1967463157",
        icon: "Skill_E_Nilou_01",
    },
    "10708": {
        nameTextMapHash: "3729293421",
        icon: "Skill_S_Nilou_01",
    },
    "10711": {
        nameTextMapHash: "2262721981",
        icon: "Skill_A_03",
    },
    "10712": {
        nameTextMapHash: "584952661",
        icon: "Skill_S_Cyno_01",
    },
    "10713": {
        nameTextMapHash: "1069392805",
        icon: "Skill_S_Cyno_02",
    },
    "10715": {
        nameTextMapHash: "2604847405",
        icon: "Skill_E_Cyno_01",
    },
    "10721": {
        nameTextMapHash: "2594921261",
        icon: "Skill_A_03",
    },
    "10722": {
        nameTextMapHash: "2160740245",
        icon: "Skill_S_Candace_01",
    },
    "10725": {
        nameTextMapHash: "2669120029",
        icon: "Skill_E_Candace_01",
    },
    "10731": {
        nameTextMapHash: "48372133",
        icon: "Skill_A_Catalyst_MD",
    },
    "10732": {
        nameTextMapHash: "3592193965",
        icon: "Skill_S_Nahida_01",
    },
    "10735": {
        nameTextMapHash: "3862968797",
        icon: "Skill_E_Nahida_01",
    },
    "10741": {
        nameTextMapHash: "1078955685",
        icon: "Skill_A_01",
    },
    "10742": {
        nameTextMapHash: "3200711933",
        icon: "Skill_S_Layla_01",
    },
    "10745": {
        nameTextMapHash: "64091533",
        icon: "Skill_E_Layla_01",
    },
    "10751": {
        nameTextMapHash: "668478821",
        icon: "Skill_A_Catalyst_MD",
    },
    "10752": {
        nameTextMapHash: "3563341277",
        icon: "Skill_S_Wanderer_01",
    },
    "10753": {
        nameTextMapHash: "3444173733",
        icon: "Skill_E_Wanderer_01",
    },
    "10755": {
        nameTextMapHash: "778366677",
        icon: "Skill_E_Wanderer_01",
    },
    "10756": {
        nameTextMapHash: "816641229",
        icon: "Skill_S_Wanderer_04",
    },
    "10757": {
        nameTextMapHash: "1485938005",
        icon: "Skill_S_Wanderer_01",
    },
    "10758": {
        nameTextMapHash: "3915592581",
        icon: "Skill_A_Catalyst_MD",
    },
    "10759": {
        nameTextMapHash: "33306749",
        icon: "Skill_S_Wanderer_02",
    },
    "10750": {
        nameTextMapHash: "92557693",
        icon: "Skill_S_Wanderer_03",
    },
    "10761": {
        nameTextMapHash: "47732325",
        icon: "Skill_A_02",
    },
    "10762": {
        nameTextMapHash: "593897829",
        icon: "Skill_S_Faruzan_01",
    },
    "10764": {
        nameTextMapHash: "4203849629",
        icon: "Skill_A_02",
    },
    "10765": {
        nameTextMapHash: "2294046741",
        icon: "Skill_E_Faruzan_01",
    },
    "20001": {
        nameTextMapHash: "1936482797",
        icon: "Skill_A_Dvalin_AirGun",
    },
    "20002": {
        nameTextMapHash: "828925397",
        icon: "Skill_A_Dvalin_AirGun",
    },
    "20011": {
        nameTextMapHash: "2656825093",
        icon: "Btn_FlightSprint",
    },
    "20012": {
        nameTextMapHash: "1189226013",
        icon: "Btn_Rises",
    },
    "20020": {
        nameTextMapHash: "1456454701",
        icon: "Btn_WaterSpirit_Skill",
    },
    "20021": {
        nameTextMapHash: "1236244093",
        icon: "Btn_BounceConjuring_Serve_S_01",
    },
    "20022": {
        nameTextMapHash: "3529333157",
        icon: "Btn_BounceConjuring_Hit_A_01",
    },
    "20023": {
        nameTextMapHash: "756850077",
        icon: "Btn_BounceConjuring_Bomb_S_01",
    },
    "20024": {
        nameTextMapHash: "4106180333",
        icon: "Btn_BounceConjuring_Bomb_S_02",
    },
    "20025": {
        nameTextMapHash: "1213295293",
        icon: "Btn_BounceConjuring_Bomb_S_03",
    },
    "20026": {
        nameTextMapHash: "3859238781",
        icon: "Btn_BounceConjuring_Bomb_S_01",
    },
    "20027": {
        nameTextMapHash: "2759617589",
        icon: "Btn_BounceConjuring_Bomb_S_02",
    },
    "20028": {
        nameTextMapHash: "4108891997",
        icon: "Btn_BounceConjuring_Bomb_S_03",
    },
    "20029": {
        nameTextMapHash: "1774915893",
        icon: "Btn_BounceConjuring_Hit_A_01",
    },
    "20030": {
        nameTextMapHash: "908300285",
        icon: "Skill_S_Monster_Shougun_EyeStrip",
    },
    "20031": {
        nameTextMapHash: "3398003357",
        icon: "Skill_E_Monster_Shougun_EyeStrip",
    },
    "20032": {
        nameTextMapHash: "147099245",
        icon: "Btn_Temari_S_01",
    },
    "20035": {
        nameTextMapHash: "2400987205",
        icon: "Skill_S_LunaRiteQuest_BanSkill",
    },
    "20036": {
        nameTextMapHash: "772855381",
        icon: "Skill_S_SummerTimeV2Quest_BanSkill",
    },
    "20037": {
        nameTextMapHash: "1636845245",
        icon: "Skill_E_SummerTimeV2Quest_BanSkill",
    },
    "20040": {
        nameTextMapHash: "3692781493",
        icon: "Btn_CatchAnimal_Shoot",
    },
    "20041": {
        nameTextMapHash: "1531349133",
        icon: "Btn_CatchAnimal_Shoot",
    },
    "20042": {
        nameTextMapHash: "3598437797",
        icon: "Btn_CatchAnimal_Shoot",
    },
    "20045": {
        nameTextMapHash: "1562204677",
        icon: "Btn_CatchAnimal_Shoot",
    },
    "20049": {
        nameTextMapHash: "1068626397",
        icon: "Btn_CatchAnimal_Shoot",
    },
    "20051": {
        nameTextMapHash: "1486834421",
        icon: "Btn_FungusFighter_Aim",
    },
    "20054": {
        nameTextMapHash: "4262868373",
        icon: "Skill_E_Gagana_AimShoot",
    },
    "20100": {
        nameTextMapHash: "4176490093",
        icon: "Btn_HideAndSeek_Seeker_A_01",
    },
    "20101": {
        nameTextMapHash: "2129541325",
        icon: "Btn_HideAndSeek_Seeker_A_01",
    },
    "20110": {
        nameTextMapHash: "459126589",
        icon: "Btn_HideAndSeek_Seeker_S_01",
    },
    "20111": {
        nameTextMapHash: "2696259549",
        icon: "Btn_HideAndSeek_Seeker_S_02",
    },
    "20120": {
        nameTextMapHash: "1169112125",
        icon: "Btn_HideAndSeek_Seeker_E_01",
    },
    "20121": {
        nameTextMapHash: "1942430565",
        icon: "Btn_HideAndSeek_Seeker_E_02",
    },
    "20122": {
        nameTextMapHash: "2720235117",
        icon: "Btn_HideAndSeek_Seeker_E_03",
    },
    "20200": {
        nameTextMapHash: "626062253",
        icon: "Btn_HideAndSeek_Hider_A_01",
    },
    "20201": {
        nameTextMapHash: "2687337709",
        icon: "Btn_HideAndSeek_Hider_A_03",
    },
    "20210": {
        nameTextMapHash: "1443145165",
        icon: "Btn_HideAndSeek_Hider_S_01",
    },
    "20212": {
        nameTextMapHash: "1163162717",
        icon: "Btn_HideAndSeek_Hider_S_01_Borbid",
    },
    "20211": {
        nameTextMapHash: "2752819013",
        icon: "Btn_HideAndSeek_Hider_S_02",
    },
    "20213": {
        nameTextMapHash: "1821490277",
        icon: "Btn_HideAndSeek_Hider_S_02_Borbid",
    },
    "20220": {
        nameTextMapHash: "7564629",
        icon: "Btn_HideAndSeek_Hider_E_01",
    },
    "20202": {
        nameTextMapHash: "644125541",
        icon: "Btn_HideAndSeek_Hider_A_01",
    },
    "20203": {
        nameTextMapHash: "1774818781",
        icon: "Btn_HideAndSeek_Hider_A_03",
    },
    "20214": {
        nameTextMapHash: "2370875301",
        icon: "Btn_HideAndSeek_Hider_S_02",
    },
    "20215": {
        nameTextMapHash: "2814338565",
        icon: "Btn_HideAndSeek_Hider_S_02_Borbid",
    },
    "20400": {
        nameTextMapHash: "2657714069",
        icon: "Btn_HideAndSeek_Seeker_A_01",
    },
    "20401": {
        nameTextMapHash: "66214933",
        icon: "Btn_HideAndSeek_Seeker_A_01",
    },
    "20410": {
        nameTextMapHash: "169502221",
        icon: "Btn_HideAndSeek_Seeker_S_01",
    },
    "20411": {
        nameTextMapHash: "1752388581",
        icon: "Btn_HideAndSeek_Seeker_S_02",
    },
    "20420": {
        nameTextMapHash: "816489501",
        icon: "Btn_HideAndSeek_Seeker_E_01",
    },
    "20421": {
        nameTextMapHash: "1050865533",
        icon: "Btn_HideAndSeek_Seeker_E_02",
    },
    "20422": {
        nameTextMapHash: "2689008917",
        icon: "Btn_HideAndSeek_Seeker_E_03",
    },
    "20500": {
        nameTextMapHash: "902040061",
        icon: "Btn_HideAndSeek_Hider_A_01",
    },
    "20501": {
        nameTextMapHash: "1233705669",
        icon: "Btn_HideAndSeek_Hider_A_03",
    },
    "20510": {
        nameTextMapHash: "2713313077",
        icon: "Btn_HideAndSeek_Hider_S_01",
    },
    "20512": {
        nameTextMapHash: "815001853",
        icon: "Btn_HideAndSeek_Hider_S_01_Borbid",
    },
    "20511": {
        nameTextMapHash: "1882966981",
        icon: "Btn_HideAndSeek_Hider_S_02",
    },
    "20513": {
        nameTextMapHash: "1833806357",
        icon: "Btn_HideAndSeek_Hider_S_02_Borbid",
    },
    "20520": {
        nameTextMapHash: "2680677653",
        icon: "Btn_HideAndSeek_Hider_E_01",
    },
    "20521": {
        nameTextMapHash: "2973812453",
        icon: "UI_Icon_Skill_Hunter_Net",
    },
    "20522": {
        nameTextMapHash: "3495989125",
        icon: "Btn_HideAndSeek_Hider_S_02",
    },
    "20523": {
        nameTextMapHash: "2450340517",
        icon: "UI_Icon_Skill_Prey_Invisible_Bait",
    },
    "20524": {
        nameTextMapHash: "1356540013",
        icon: "Btn_HideAndSeek_Seeker_S_01",
    },
    "20525": {
        nameTextMapHash: "3710444509",
        icon: "Btn_HideAndSeek_Hider_A_01",
    },
    "20526": {
        nameTextMapHash: "1656473773",
        icon: "Btn_HideAndSeek_Hider_A_03",
    },
    "20311": {
        nameTextMapHash: "467388069",
        icon: "Btn_Fishing_Cast",
    },
    "20312": {
        nameTextMapHash: "3754566189",
        icon: "Btn_Fishing_Battle",
    },
    "20313": {
        nameTextMapHash: "3826517485",
        icon: "Btn_Fishing_Battle",
    },
    "20314": {
        nameTextMapHash: "3875153725",
        icon: "Btn_Fishing_Pull",
    },
    "20315": {
        nameTextMapHash: "2615366341",
        icon: "Btn_Fishing_Exit",
    },
    "20316": {
        nameTextMapHash: "2392743845",
        icon: "Btn_Fishing_Bait",
    },
    "20320": {
        nameTextMapHash: "4091597733",
        icon: "Btn_Blocking",
    },
    "20330": {
        nameTextMapHash: "1226553101",
        icon: "Btn_Arana_Shoot",
    },
    "20331": {
        nameTextMapHash: "77403669",
        icon: "Btn_Arana_Exchange",
    },
    "20340": {
        nameTextMapHash: "3940661125",
        icon: "Btn_BrickBreaker_Launch",
    },
    "10384": {
        nameTextMapHash: "1543775045",
        icon: "Btn_Recon_Bait",
    },
    "100540": {
        nameTextMapHash: "1952055533",
        icon: "Skill_A_01",
    },
    "100541": {
        nameTextMapHash: "3198281757",
        icon: "Skill_A_01",
    },
    "100542": {
        nameTextMapHash: "3565118517",
        icon: "Skill_A_01",
    },
    "100543": {
        nameTextMapHash: "3283214237",
        icon: "Skill_A_01",
    },
    "100544": {
        nameTextMapHash: "895313525",
        icon: "Skill_A_01",
    },
    "100545": {
        nameTextMapHash: "379244133",
        icon: "Skill_A_01",
    },
    "100546": {
        nameTextMapHash: "1660121349",
        icon: "Skill_A_01",
    },
    "100547": {
        nameTextMapHash: "3401752693",
        icon: "Skill_A_01",
    },
    "100550": {
        nameTextMapHash: "3538369725",
        icon: "Skill_A_01",
    },
    "100551": {
        nameTextMapHash: "2463434149",
        icon: "Skill_A_01",
    },
    "100552": {
        nameTextMapHash: "299520933",
        icon: "Skill_A_01",
    },
    "100553": {
        nameTextMapHash: "2182891949",
        icon: "Skill_A_01",
    },
    "100554": {
        nameTextMapHash: "1522492485",
        icon: "Skill_A_01",
    },
    "100555": {
        nameTextMapHash: "1063935965",
        icon: "Skill_A_01",
    },
    "100556": {
        nameTextMapHash: "3021322565",
        icon: "Skill_A_01",
    },
    "100557": {
        nameTextMapHash: "1727970205",
        icon: "Skill_A_01",
    },
    "5002010": {
        nameTextMapHash: "1113979477",
        icon: "Skill_A_01",
    },
    "5003010": {
        nameTextMapHash: "2743040301",
        icon: "Skill_A_01",
    },
    "5005010": {
        nameTextMapHash: "222670213",
        icon: "Skill_A_01",
    },
    "5005020": {
        nameTextMapHash: "599206293",
        icon: "Skill_A_01",
    },
    "5005030": {
        nameTextMapHash: "3869306797",
        icon: "Skill_A_01",
    },
    "5005040": {
        nameTextMapHash: "537185229",
        icon: "Skill_A_01",
    },
    "5005050": {
        nameTextMapHash: "458080989",
        icon: "Skill_A_01",
    },
    "5005060": {
        nameTextMapHash: "3662398749",
        icon: "Skill_A_01",
    },
    "5005070": {
        nameTextMapHash: "2768383149",
        icon: "Skill_A_01",
    },
    "5005080": {
        nameTextMapHash: "2048192477",
        icon: "Skill_A_01",
    },
    "5006010": {
        nameTextMapHash: "1861301005",
        icon: "Skill_A_Catalyst_MD",
    },
    "5007010": {
        nameTextMapHash: "4224921045",
        icon: "Skill_A_01",
    },
    "5007020": {
        nameTextMapHash: "900526901",
        icon: "Skill_A_01",
    },
    "5007030": {
        nameTextMapHash: "811245917",
        icon: "Skill_A_01",
    },
    "5007040": {
        nameTextMapHash: "2422927957",
        icon: "Skill_A_01",
    },
    "5007050": {
        nameTextMapHash: "3923422245",
        icon: "Skill_A_01",
    },
    "5007060": {
        nameTextMapHash: "3851684133",
        icon: "Skill_A_01",
    },
    "5007070": {
        nameTextMapHash: "2772749133",
        icon: "Skill_A_01",
    },
    "5007080": {
        nameTextMapHash: "2138619645",
        icon: "Skill_A_01",
    },
    "5014010": {
        nameTextMapHash: "3673252189",
        icon: "Skill_A_Catalyst_MD",
    },
    "5015010": {
        nameTextMapHash: "146347653",
        icon: "Skill_A_01",
    },
    "5016010": {
        nameTextMapHash: "1059884597",
        icon: "Skill_A_04",
    },
    "5020010": {
        nameTextMapHash: "2307867765",
        icon: "Skill_A_04",
    },
    "5021010": {
        nameTextMapHash: "2465177213",
        icon: "Skill_A_02",
    },
    "5022010": {
        nameTextMapHash: "1880336189",
        icon: "Skill_A_02",
    },
    "5023010": {
        nameTextMapHash: "2947930693",
        icon: "Skill_A_03",
    },
    "5024010": {
        nameTextMapHash: "1202874949",
        icon: "Skill_A_04",
    },
    "5025010": {
        nameTextMapHash: "2555769645",
        icon: "Skill_A_01",
    },
    "5026010": {
        nameTextMapHash: "2718102949",
        icon: "Skill_A_03",
    },
    "5027010": {
        nameTextMapHash: "3736001053",
        icon: "Skill_A_Catalyst_MD",
    },
    "5029010": {
        nameTextMapHash: "1277261805",
        icon: "Skill_A_Catalyst_MD",
    },
    "5030010": {
        nameTextMapHash: "1444388789",
        icon: "Skill_A_03",
    },
    "5031010": {
        nameTextMapHash: "4251380141",
        icon: "Skill_A_02",
    },
    "5032010": {
        nameTextMapHash: "807465973",
        icon: "Skill_A_01",
    },
    "5033010": {
        nameTextMapHash: "2269716989",
        icon: "Skill_A_02",
    },
    "5034010": {
        nameTextMapHash: "120782533",
        icon: "Skill_A_04",
    },
    "5035010": {
        nameTextMapHash: "3686145989",
        icon: "Skill_A_01",
    },
    "5036010": {
        nameTextMapHash: "641926669",
        icon: "Skill_A_04",
    },
    "5037010": {
        nameTextMapHash: "2828744293",
        icon: "Skill_A_02",
    },
    "5038010": {
        nameTextMapHash: "2495101917",
        icon: "Skill_A_01",
    },
    "5039010": {
        nameTextMapHash: "562318989",
        icon: "Skill_A_02",
    },
    "5041010": {
        nameTextMapHash: "1558817893",
        icon: "Skill_A_Catalyst_MD",
    },
    "5042010": {
        nameTextMapHash: "2442023485",
        icon: "Skill_A_01",
    },
    "5043010": {
        nameTextMapHash: "3753429733",
        icon: "Skill_A_Catalyst_MD",
    },
    "5044010": {
        nameTextMapHash: "1747345901",
        icon: "Skill_A_04",
    },
    "5045010": {
        nameTextMapHash: "3381185701",
        icon: "Skill_A_03",
    },
    "5046010": {
        nameTextMapHash: "1471470213",
        icon: "Skill_A_03",
    },
    "5047010": {
        nameTextMapHash: "7068229",
        icon: "Skill_A_01",
    },
    "5048010": {
        nameTextMapHash: "1054428893",
        icon: "Skill_A_Catalyst_MD",
    },
    "5049010": {
        nameTextMapHash: "534393685",
        icon: "Skill_A_02",
    },
    "5050010": {
        nameTextMapHash: "889413773",
        icon: "Skill_A_03",
    },
    "5051010": {
        nameTextMapHash: "3123794733",
        icon: "Skill_A_04",
    },
    "5052010": {
        nameTextMapHash: "2761964765",
        icon: "Skill_A_03",
    },
    "5053010": {
        nameTextMapHash: "3251301293",
        icon: "Skill_A_04",
    },
    "5054010": {
        nameTextMapHash: "2462540765",
        icon: "Skill_A_Catalyst_MD",
    },
    "5055010": {
        nameTextMapHash: "1061636741",
        icon: "Skill_A_02",
    },
    "5056010": {
        nameTextMapHash: "1602190341",
        icon: "Skill_A_02",
    },
    "5058010": {
        nameTextMapHash: "2500225021",
        icon: "Skill_A_Catalyst_MD",
    },
    "5057010": {
        nameTextMapHash: "752149869",
        icon: "Skill_A_04",
    },
    "5059010": {
        nameTextMapHash: "3825685805",
        icon: "Skill_A_Catalyst_MD",
    },
    "5060010": {
        nameTextMapHash: "289877085",
        icon: "Skill_A_02",
    },
    "5062010": {
        nameTextMapHash: "1225242717",
        icon: "Skill_A_02",
    },
    "5063010": {
        nameTextMapHash: "1461236069",
        icon: "Skill_A_03",
    },
    "5064010": {
        nameTextMapHash: "4228672181",
        icon: "Skill_A_03",
    },
    "5065010": {
        nameTextMapHash: "3189479301",
        icon: "Skill_A_01",
    },
    "5066010": {
        nameTextMapHash: "2509253013",
        icon: "Skill_A_01",
    },
    "5067010": {
        nameTextMapHash: "1232154725",
        icon: "Skill_A_02",
    },
    "5068010": {
        nameTextMapHash: "2106573173",
        icon: "Skill_A_04",
    },
    "5069010": {
        nameTextMapHash: "19903157",
        icon: "Skill_A_02",
    },
    "5070010": {
        nameTextMapHash: "280269733",
        icon: "Skill_A_01",
    },
    "5071010": {
        nameTextMapHash: "2022718829",
        icon: "Skill_A_03",
    },
    "5072010": {
        nameTextMapHash: "3497260069",
        icon: "Skill_A_03",
    },
    "5073010": {
        nameTextMapHash: "286439061",
        icon: "Skill_A_Catalyst_MD",
    },
    "5074010": {
        nameTextMapHash: "1942178429",
        icon: "Skill_A_01",
    },
    "5075010": {
        nameTextMapHash: "1285477197",
        icon: "Skill_A_Catalyst_MD",
    },
    "5076010": {
        nameTextMapHash: "405719917",
        icon: "Skill_A_02",
    },
};
