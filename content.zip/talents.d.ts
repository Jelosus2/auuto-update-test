export declare const talents: {
    [key: string]: any;
};
