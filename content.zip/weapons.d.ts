export declare const weapons: {
    [key: string]: any;
};
